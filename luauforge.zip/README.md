# LuauForge

A free Luau and Roblox scripting assistant. It runs in the browser: no account, no API key, no server.

## Use it

Double-click `index.html`. Docs mode works right away: it answers from 57 built-in Luau and Roblox notes and checks any script you paste.

## Put it online (GitHub Pages)

1. Create a new public GitHub repository.
2. Upload `index.html` and `.nojekyll` to the root of the repository.
3. Open Settings > Pages, choose "Deploy from a branch", select `main` and `/ (root)`, then save.
4. After about a minute your site is live at `https://<your-username>.github.io/<repository>/`.

## The AI model

Click **Load AI model** on the hosted site. It needs a recent Chrome or Edge with WebGPU and downloads 1 to 5 GB the first time (the browser keeps it afterwards). It is free and runs on your own GPU. It does not work when you open `index.html` as a file, only when the page is hosted.

## Good to know

- A small model in a browser is weaker than big hosted models. LuauForge is useful because of its Luau notes and its code checker, which makes the AI fix deprecated or unsafe code.
- It learns from you through **Lessons** (Good answer, Correct it). The model itself does not change.
- Check each model's license on its Hugging Face page before using it in a commercial game. I believe the 3B model is research-only, so choose 1.5B or 7B for commercial use.
- Nothing you type leaves your browser.
